document.getElementById('learnMore').addEventListener('click', () => {
alert('Itt több információt találsz a szolgáltatásainkról!');
});